import { Menu } from "antd";
import { AppstoreOutlined, ApartmentOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";

function SideMenu() {
    const nav = useNavigate();
    return <div className="SideMenu">
        <Menu
            style={{height: "100%"}}
            mode="vertical"
            onClick={(item: any) => {
                nav(item.key);
            }}
            items={[
                {
                    label: "Nodes",
                    key: "/",
                    icon: <AppstoreOutlined style={{ fontSize: 22 }} />
                },
                {
                    label: "Permissions",
                    key: "/orgstructure",
                    icon: <ApartmentOutlined style={{ fontSize: 22 }} />
                },
            ]}>

        </Menu>
    </div>;
}

export default SideMenu;