import { Image, Typography, Space } from "antd";
import { SettingOutlined } from "@ant-design/icons";

function AppHeader() {
    return <div className="AppHeader">
        <Image width={50} src="../../partior-logo.jpeg"></Image>
        <Typography.Title style={{ color: "white", fontSize: 24 }}>Partior Network</Typography.Title>
        <Space>
            <SettingOutlined style={{ color: "white", fontSize: 24}} />
        </Space>
    </div>;
}

export default AppHeader;