const express = require('express');
const cors = require('cors');
const app = express();
const port = 3030; // You can choose any available port number

app.use(cors());

app.get('/', (req, res) => {
    res.send('Ok!');
});

app.get('/api/nodes', (req, res) => {
    res.send(
        [
            { nodeName: "ptr1", blockNumber: 2543, peers: 4, enhancedPermissioning: true, status: "online" },
            { nodeName: "ptr2", blockNumber: 2543, peers: 4, enhancedPermissioning: true, status: "online" },
            { nodeName: "ptr3", blockNumber: 2543, peers: 4, enhancedPermissioning: true, status: "offline" },
            { nodeName: "ptr4", blockNumber: 2543, peers: 4, enhancedPermissioning: false, status: "online" },
            { nodeName: "newnode10", blockNumber: 2543, peers: 4, enhancedPermissioning: false, status: "offline" }
        ]
    );
});

app.get('/api/permissions', (req, res) => {
    res.send(
        [
            {
                orgId: "PARTIOR_NETWORK", subOrgs: [
                    { orgId: "PTR2_SUB_ORG", subOrgs: [], accounts: [{ accountId: "0xAccountPtr2", roleName: "ORGADMIN", isAdmin: true, accessLevel: 3 }], nodes: [] },
                    { orgId: "PTR3_SUB_ORG", subOrgs: [], accounts: [{ accountId: "0xAccountPtr3", roleName: "ORGADMIN", isAdmin: true, accessLevel: 3 }], nodes: [] },
                    { orgId: "PTR4_SUB_ORG", subOrgs: [], accounts: [{ accountId: "0xAccountPtr4", roleName: "ORGADMIN", isAdmin: true, accessLevel: 3 }], nodes: [] }
                ],
                accounts: [
                    { accountId: "0xAccountPtr1", roleName: "ADMIN", isAdmin: true, accessLevel: 3 }
                ],
                nodes: [
                    {enodeId: "enode://1237812931982379817298312398@127.0.0.1:30303?discport=0"},
                    {enodeId: "enode://9871237681231231231231231231@127.0.0.1:30303?discport=0"},
                    {enodeId: "enode://9182739828982379817298312123@127.0.0.1:30303?discport=0"},
                    {enodeId: "enode://7627631283718923123123123123@127.0.0.1:30303?discport=0"},
                    {enodeId: "enode://5271623233982379817298312398@127.0.0.1:30303?discport=0"}

                ]
            }
        ]
    );
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
