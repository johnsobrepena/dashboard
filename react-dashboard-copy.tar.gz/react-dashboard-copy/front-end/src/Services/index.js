const apiUrl = "http://localhost:3030"

export const getNodes = () =>{
    return fetch(`${apiUrl}/api/nodes`).then((res) => res.json());
}
