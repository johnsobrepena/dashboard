import { Typography, Tree } from "antd";
import { DownOutlined, ApartmentOutlined, UserOutlined, HddOutlined } from '@ant-design/icons';

const treeData = [
    {
        title: 'parent 1',
        key: '0-0',
        icon: <ApartmentOutlined className="IconOrgStyle" />,
        children: [
            {
                title: 'parent 1-0',
                key: '0-0-0',
                icon: <ApartmentOutlined className="IconOrgStyle" />,
                children: [
                    {
                        title: 'leaf',
                        key: '0-0-0-0',
                        icon: <UserOutlined className="IconAccountStyle" />
                    },
                    {
                        title: 'leaf',
                        key: '0-0-0-1',
                        icon: <HddOutlined className="IconNodeStyle" />
                    },
                    {
                        title: 'leaf',
                        key: '0-0-0-2',
                        icon: <HddOutlined className="IconNodeStyle" />
                    },
                ],
            },
            {
                title: 'parent 1-1',
                key: '0-0-1',
                icon: <ApartmentOutlined className="IconOrgStyle" />,
                children: [
                    {
                        title: 'leaf',
                        key: '0-0-1-0',
                        icon: <UserOutlined className="IconAccountStyle" />
                    },
                ],
            },
            {
                title: 'parent 1-2',
                key: '0-0-2',
                icon: <ApartmentOutlined className="IconOrgStyle" />,
                children: [
                    {
                        title: 'leaf',
                        key: '0-0-2-0',
                        icon: <UserOutlined className="IconAccountStyle" />
                    },
                    {
                        title: 'leaf',
                        key: '0-0-2-1',
                        icon: <HddOutlined className="IconNodeStyle" />
                    },
                ],
            },
            {
                title: 'parent 1-3',
                key: '0-0-3',
                icon: <UserOutlined className="IconAccountStyle" />
            },
            {
                title: <div style={{ display: "inline-block" }}>
                    parent 1-4
                    <div style={{ display: "inline-block", fontSize: "8pt", marginLeft: 4, paddingLeft: 4, paddingRight: 4, borderWidth:1, borderRadius: 6, borderStyle:"solid", borderColor: "orange" }}>Administrator</div>
                </div>,
                key: '0-0-4',
                icon: <HddOutlined className="IconNodeStyle" />
            },
            {
                title: 'parent 1-5',
                key: '0-0-5',
                icon: <HddOutlined className="IconNodeStyle" />
            }
        ],
    },
];

function PermissionStructure() {
    return <div>
        <Typography.Title level={4}>Permission Structure</Typography.Title>
        <Tree
            showIcon
            showLine
            switcherIcon={<DownOutlined />}
            defaultExpandedKeys={['0-0']}
            treeData={treeData}
        />
    </div>;
}

export default PermissionStructure;