import { Typography, Space, Card, Statistic, Descriptions, Image, Badge } from "antd";
import { BlockOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import { getNodes } from "../../Services";

function Dashboard() {
    const [loading, setLoading] = useState(false);
    const [dataSource, setDataSource] = useState([]);

    useEffect(() => {
        //setDataSource([]);
        setLoading(true);
        getNodes().then((data) => {
            setDataSource(data);
            setLoading(false);
        });
    }, []);

    return <div>
        <Typography.Title level={4}>Nodes</Typography.Title>
        <div style={{ display: "flex", flexWrap: "wrap" }}>
            {dataSource.map((item) => (
                <NodeCard key={item.nodeName} 
                nodeName={item.nodeName} 
                peers={item.peers} 
                blockNumber={item.blockNumber}
                enhancedPermissioning={item.enhancedPermissioning}
                status={item.status} />
            ))}
        </div>
    </div>;
}

function NodeCard({ nodeName, blockNumber, peers, enhancedPermissioning, status }) {
    let epColor = "gray";
    let epText = "--";
    let nodeColor = "lightgray";

    if (status=="online"){
        nodeColor = "#C1E1C1";
    }else{
        blockNumber="----";
        peers="----";
    }

    if (enhancedPermissioning){
        epColor = "#008080";
        epText = "EP";
    }

    return (
        <div style={{padding:8}}>
            <Badge.Ribbon text={epText} color={epColor}>
                <Card size="small"
                    style={{ backgroundColor: nodeColor, with: 180, height: 150 }}>
                    <div className="CardTitle">
                        <Image width={35} src="../../cube_icon.png" style={{ paddingRight: 6 }}></Image>
                        {nodeName}
                    </div>
                    <Space direction="horizontal" size={0}>
                        <div style={{ marginLeft: 8 }}>
                            <div className="CardSmallLabel">Block Number</div>
                            <div className="CardValueText">{blockNumber}</div>
                            <div className="CardSmallLabel">Peers</div>
                            <div className="CardValueText">{peers}</div>
                        </div>
                    </Space>
                </Card>
            </Badge.Ribbon>
        </div>);
}

export default Dashboard;