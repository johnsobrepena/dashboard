import {Typography} from "antd";

function AppFooter() {
    return <div className="AppFooter">
        <Typography.Link>helixteam</Typography.Link>
    </div>;
}

export default AppFooter;