import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "../../Pages/Dashboard";
import PermissionStructure from "../../Pages/PermissionStructure";

function AppRoutes() {
    return (
        <Routes>
            <Route path="/" element={<Dashboard />}></Route>
            <Route path="/orgstructure" element={<PermissionStructure />}></Route>
        </Routes>
    );
}

export default AppRoutes;